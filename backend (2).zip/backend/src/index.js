//express wala idhar se fetch hoga
const express = require('express');
// express chalu krne ke liyee
const app = express();
//iise css dikhega apne ko
app.use(express.static("public"));
//path ayega ise inbuild hyy
const path = require('path')
// isse apna password safe rhega
const bcrypt = require("bcrypt")
// isse apun apna html ka replacement hbs ko use kr skte
const hbs = require("hbs");
const collection = require("./mongodb")

const templatePath = path.join(__dirname, "../templates")


app.use(express.json())
app.set("view engine", "hbs")
//by default the name of template is used by name view so we are changing it here
app.set("views", templatePath)
app.use(express.urlencoded({ extended: false }))

// const publicPath=path.resolve(__dirname,"public");

// app.use(express.static(publicPath));


app.get("/", (req, res) => {
    res.render("login")
})


app.get("/signup", (req, res) => {
    res.render("signup")
})


app.post("/signup", async (req, res) => {

    // this the required data in signup form
    const data = {
        firstname: req.body.firstname,
        lastname: req.body.lastname,
        email: req.body.email,
        password: req.body.password
    }

    const existinguser = await collection.findOne({ email: data.email });

    //if the user with same name exist throw error
    if (existinguser) {
        res.send("Email already exist try with other Email");
    }
    else {

        const saltRounds = 10; //number of salt round for bcrypt
        const hashedPassword = await bcrypt.hash(data.password, saltRounds);

        data.password = hashedPassword; //replaced hased password with original password

        // now moongo will create a data and stored it there
        await collection.insertMany([data])
        res.render("home")

    }
})

app.post("/login", async (req, res) => {

    // this the data format for login page 

    try {
        const check = await collection.findOne({ email: req.body.email })

        if (!check) {
            res.send("Invalid Credentials")
        }

        //comapre the hash password fromthe database with the plain text
        const isPasswordMatch = await bcrypt.compare(req.body.password, check.password);
        if (isPasswordMatch) {
            res.render("home");
        }
        else {
            res.send("Invalid Credentials")
        }
    } catch {
        res.send("Invalid Credentials")
    }
})

app.listen(3050, () => {
    console.log("port connected");
})
