const mongoose=require("mongoose");

// this the way we connect to our mongo db file which has  been created
mongoose.connect("mongodb://localhost:27017/backend")
.then(()=>{
    console.log("mongo connected")
})
.catch(()=>{
    console.log("failed to connect");
})

//this the formate how will the name and pass will be stored
const LogInSchema=new mongoose.Schema({
    firstname:{
        type: String,
        required:true,
        trim:true,
        maxlength:30, 
    },
    lastname:{
        type: String,
        required:true,
        maxlength:30,
    },
    email:{
        type: String,
        unique:true,
        required:true
    },
    password:{
        type:String,
        required:true
    }
})

const collection=new mongoose.model("Collection1",LogInSchema)

//this the way we collect the item and get in index file
module.exports=collection
